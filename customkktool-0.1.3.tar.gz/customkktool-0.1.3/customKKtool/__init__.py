import os, sys

def get_code():
    base_path = os.path.dirname(os.path.abspath(__file__))

    # Lấy version chính xác
    major = sys.version_info.major      # 3
    minor = sys.version_info.minor      # 11 / 12 / …

    # Tạo tên file theo version — ví dụ: custom_311.py
    version_filename = f"custom_{major}{minor}.py"
    version_path = os.path.join(base_path, version_filename)

    # Nếu file version tồn tại → dùng nó
    if os.path.exists(version_path):
        load_path = version_path
    else:
        # fallback về custom.py
        load_path = os.path.join(base_path, "custom.py")

    # Đọc code
    with open(load_path, "r", encoding="utf-8") as f:
        code = f.read()

    return code
