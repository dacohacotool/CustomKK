from setuptools import setup, find_packages

setup(
    name="customKKtool",
    version="0.1.3",
    packages=find_packages(),
    install_requires=["rich", "requests", "certifi", "colorama", "tqdm"],
    python_requires='>=3.11, <3.13',  # <--- chỉ 3.11 và 3.12
    author="KKtool - Dongdangkhoi",
    description="Công cụ KKtool tổng hợp các thư viện tiện ích",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown"
)