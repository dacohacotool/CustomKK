# customKKtool

Thư viện KKtool để load các module tùy chỉnh.

```python
from customKKtool import get_code

# Load code từ package
exec(get_code(), globals())

# Khởi tạo CustomKK
___CustomKK___('All.hashKK')

# Load các module bổ sung
def InportModuleKK():
    try:
        required_files = ['kkmd', 'fbViAiPi']
        loadp(required_files)
    except:
        if debug_mode:
            import traceback
            traceback.print_exc()
            input()

from rich.spinner import Spinner

with Spinner(text='Đang tải thư viện'):
    InportModuleKK()